<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>EDMS-Document</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>7e6918b5-d10e-400a-b0f2-8bdd3de3ae03</testSuiteGuid>
   <testCaseLink>
      <guid>097ecd09-e431-46a5-9f6e-7beff4cb53a8</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/Archieve</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>78582ceb-f329-4215-a3a9-ecef96f24b74</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/shared doc</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8514314d-9642-4272-91f3-8643bd1f5228</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/my document</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
