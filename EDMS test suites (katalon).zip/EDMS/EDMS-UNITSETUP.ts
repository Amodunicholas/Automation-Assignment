<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>EDMS-UNITSETUP</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>471de45f-61fa-46dc-a43a-f98396ae0e7f</testSuiteGuid>
   <testCaseLink>
      <guid>5ce24328-1acf-4c43-8a0c-291c84e894cc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/Business Unit</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b68164cb-c2c4-4ee2-9c88-4213c84eef4a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/Entity Mgt</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f446bbb2-2103-4e8f-b006-0b7777c753ac</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/Profile user</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>39181059-f103-472e-a78b-15ce1962b5e9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/user group</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e916eebe-25fd-4b49-aa0a-1d85fd893fbb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/User group type</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>92fbfcef-36ae-465e-acea-3c1a7e73ac71</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/user role</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
