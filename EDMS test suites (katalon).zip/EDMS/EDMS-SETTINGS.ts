<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>EDMS-SETTINGS</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>a08e2b8a-2168-41eb-a99e-f2987102a2fd</testSuiteGuid>
   <testCaseLink>
      <guid>ea91bfa7-6096-4e28-9099-1352239ce3a6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/Document property</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7072cef2-8ac3-4392-b379-e4919d750f96</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/shared doc</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>3ae65ed1-7677-494c-83bd-3c2b6206195f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/storage setting</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
