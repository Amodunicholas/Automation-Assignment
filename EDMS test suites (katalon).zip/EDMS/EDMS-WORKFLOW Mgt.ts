<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>EDMS-WORKFLOW Mgt</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>acdf7eb9-3fab-4b9d-94e3-d077953ecefb</testSuiteGuid>
   <testCaseLink>
      <guid>6720658c-d09b-4a30-ba6d-7fd30c8a7782</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/EDMS APP/workflow management</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
